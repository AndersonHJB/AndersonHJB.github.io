<!doctype html>
<html>
    <head>
        <title>Movie Database</title>
        <style>

        </style>
    </head>
    <body>
        <h1>My Movie Database: View</h1>

        <?php
            include('header.php');
        ?>

        <!-- grab all movies from the database and display to the user -->
        <?php

            // connect to database
            $dbpath = getcwd() . '/database/movies.db';
            $db = new SQLite3($dbpath);


            // set up a SQL query to get all movies from the table
            $sql = "SELECT id, title, year FROM movies";
            $statement = $db->prepare($sql);
            $result = $statement->execute();
        

            // iterate over those movies and generate output
            while ($array = $result->fetchArray()) {

                print $array['id'] . ' - ' . $array['title'] . ' - ' . $array['year'] . '<a href="delete.php">Delete</a>' . '<br>';

            }

            $db->close();
            unset($db);

        ?>



    </body>

</html>